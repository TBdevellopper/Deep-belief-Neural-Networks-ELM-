function dataout = S(In,minval,maxval)
dataout = In - min(In(:));
dataout = (dataout/range(dataout(:)))*(maxval-minval);
dataout = dataout + minval;