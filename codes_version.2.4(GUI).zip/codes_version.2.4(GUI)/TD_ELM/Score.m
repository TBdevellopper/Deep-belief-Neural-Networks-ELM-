function[SCORE,S,d,er]=Score(YPred,Y)
a=iscell(YPred);
if a==1
result=[];rul1=[];
for i = 1:numel(YPred)
    R(i)=Y{i}(end);
    YPredLast(i) = YPred{i}(end);
    result=[ result; YPredLast(i)];
    rul1=[rul1;R(i)];
end
earlyPenalty = 13;
latePenalty = 10;
d = result - rul1;
S = zeros(size(d));
%%%LATE prediction, pred > trueRUL, pred - trueRUL > 0
f = find(d >= 0);
FNR = length(f) / length(rul1); % false negative rate
S(f) = exp(d(f)/latePenalty)-1;
%%%%EARLY
f = find(d < 0);
FPR = length(f) / length(rul1);% false positive rate
S(f) = exp(-d(f)/earlyPenalty)-1;
SCORE=sum(S);
er=sqrt(d.^2);
else
 result=YPred;rul1=Y; 
 earlyPenalty = 13;
latePenalty = 10;
d = result - rul1;
S = zeros(size(d));
%%%LATE prediction, pred > trueRUL, pred - trueRUL > 0
f = find(d >= 0);
FNR = length(f) / length(rul1); % false negative rate
S(f) = exp(d(f)/latePenalty)-1;
%%%%EARLY
f = find(d < 0);
FPR = length(f) / length(rul1);% false positive rate
S(f) = exp(-d(f)/earlyPenalty)-1;
SCORE=sum(S);
er=sqrt(d.^2);
    
end
end