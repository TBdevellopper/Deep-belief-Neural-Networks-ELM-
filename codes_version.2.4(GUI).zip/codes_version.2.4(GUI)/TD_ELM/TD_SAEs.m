function [net]=TD_SAEs(Trinputs,Tsinputs,Options)
% TD_SAEs : Temporal Differance Online Sequential Extrem Learning Machine
% for training of the Stacked Autoencoder (SAEs)

% Inputs

% Trinputs : training inputs 
% Trtargets: training targets
% Tsinputs : testing inputs
% Tstargets: testing targets
% Options  : training Options

% Outputs 

% net:the trained network 

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% %%%%% AUTHOR     : BERGHOUT TAREK
% %%%%% UNIVERSITY : BATNA 2 university Algeria 
% %%%%% EMAIL      : berghouttarek@gmail
% %%%%% UPDATED    : 19.01.2020; 10:54 am. algeria 
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%
%
%
%
%
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Load Options

activF=Options.activF;                            %  Activation function
SAEs_Architecture=Options.SAEs_Architecture;%  Network Architecture
lambdaMin=Options.lambdaMin;                      %  minimal value of  forgeting factor
mu=Options.mu;                                    %  sensitivity factor
gamma=Options.gamma;                              %  Discount factor
C=Options.C;                                      %  regularization parameter

% Start training 
% Initialization phase
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
h = waitbar(0,'Please wait...');
start_time_train=cputime;
for i=1:length(SAEs_Architecture) 
waitbar(i / length(SAEs_Architecture))    
% load initial mini-batches                                           
if i==1
P = Trinputs{1}; 
else
P=S(Hn{1}',0,1);% scaling
end                                    
% generate input weights
input_weights=rand(SAEs_Architecture(i),size(P,2));         
% calculating the temporal hidden layer 
% formula (1) 
tempH=input_weights*P';                 
% Activation function
 switch lower(activF)
    case {'sig','sigmoid'}
        %%%%%%%% Sigmoid 
        H = 1 ./ (1 + exp(-tempH));
    case {'radbas'}
        %%%%%%%% Radial basis function
        H = radbas(tempH);
%%%%%% More activation functions can be added here                
 end 
% save the new features representations  
Hn{1}=H; 
% calculate beta
% formula (1) 
B=pinv(H') * P ; 
% calculate the covariance matrix
% formula (8)
M = pinv((C)+H * H');
% end  of initialization  phase
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% start sequential Learning
c=0;% initialize counter of lamdas
% formula (5)
E{1}=P-(H'*B);% initial TD
if numel(Trinputs)>1%                   
for t=2:numel(Trinputs)-1
c=c+1;
% load new mini-batches 
     if i==1
Pnew = Trinputs{t}; 
    else
Pnew =S(Hn{t}',0,1); % scaling 
     end
% temporal hidden layer
% we no longer need the old input weighting matrix,
% we will use pinv (B ') instead.
% input_weights = pinv(B')

% you can use equation (16) :

Hn{t}=pinv(B')*Pnew';

% %%%%%Activation function%%%
% no need to the use of activation function
% activation beta is already calculated after activation

% calculate TD

% formula (10)
E{t}=Pnew-((Hn{t}-gamma*Hn{t-1})' * B);% error
% USS (updated sellection strategy )
% condition in formula (9)
% set intial lambda 
if t==2
lambda=lambdaMin;
else
lambda=lamdas(1,c-1);    
end
%%%

if sqrt(mse(E{t}))>sqrt(mse(E{t-1}))
% boundary constraints Adjustement for lambda (forgeting factor)
% formula (13)
if lambda<=lambdaMin
 lambda=lambdaMin;
elseif lambda>=1
 lambda=1;    
end
% Update lamda
lambda=lambdaMin+(1-lambdaMin)*exp(-mu*sqrt(mse(E{t})));
% Gain matrix
% formula (12)
K =(M * Hn{t}) *((lambda+eye(size(Pnew,1))+(Hn{t}-gamma*Hn{t-1})' * M * Hn{t})^(-1));
% Covariance matrix
% formula (11)
M = (1/lambda)*(M -( K * (Hn{t}-gamma*Hn{t-1})' * M));
% Output weights beta
% formula (9)
B = B + M * Hn{t} * (E{t});
end
lamdas(1,c)=lambda;
end
end
%save updated beta
weights{i}=B;                        
end
close(h)
end_time_train=cputime;
Tr_Time=end_time_train-start_time_train;
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

%%%%%% training accuracy
 for t=1:numel(Trinputs)
     % encoding
   input=Trinputs{t};
   for i=1:length(SAEs_Architecture)
   B=weights{i};
   H=pinv(B')*input';
   input=H';
   end
   mapping_TRAIN{t}=input;
     % decoding
   while i>0 
   B=weights{i};
   tr_output{t}=H'*B;
   H=tr_output{t}';
   i=i-1;% walking one step backword
   end

Tr_acc(t)=sqrt(mse(tr_output{t}-Trinputs{t}));
 end
 trainingAccuracy=mean(Tr_acc);
 %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 
 %%%%%% testing accuracy
 start_time_test=cputime;

 for t=1:numel(Tsinputs)
     % encoding
   input=Tsinputs{t}';
   for i=1:length(SAEs_Architecture)
   B=weights{i};
   H=pinv(B')*input';
   input=H';
   end
   mapping_TEST{t}=input';
     % decoding
   while i>0 
   B=weights{i};
   ts_output{t}=H'*B;
   H=ts_output{t}';
   i=i-1;% walking one step backword
   end
Ts_acc(t)=sqrt(mse(ts_output{t}-Tsinputs{t}'));
 end
testingAccuracy=mean(Ts_acc);
Ts_Time=cputime-start_time_test;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Save results
  net.Tr_Time=Tr_Time;
  net.Ts_Time=Ts_Time;
  net.beta=weights;
  net.mapping_Train=mapping_TRAIN;
  net.mapping_Test=mapping_TEST;
  net.Tr_RMSE=trainingAccuracy;
  net.Ts_RMSE=testingAccuracy;
 
end
