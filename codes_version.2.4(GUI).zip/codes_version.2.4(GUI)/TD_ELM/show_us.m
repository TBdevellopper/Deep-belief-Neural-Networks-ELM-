function show_us(net)
%% plot{USS : Updated Selection Strategy}
figure (1)
plot(1:length(net.R_TrM),net.R_TrM...
    ,'k:',...
    1:length(net.R_TrM),net.R_TrM...
    ,'b*',net.Index,...
    net.R_TrM(net.Index),'r*'...
    ,'LineWidth',2)
xlabel('Training mini-batches','FontName','Times New Roman','FontSize',14);
ylabel('RMSE of training','FontName','Times New Roman','FontSize',14);
legend('RMSE','Ignored mini-batches','Selected mini-batches');

%% plot(RUL) of a set of engines from the test set
% the user has the ability to choose any engine , 
% i: is the desired  number of engine 
figure(3)
subplot(1,4,1)
i=18;
plot(1:length(net.Yts_hat{i}),net.Yts_hat{i},'r*',1:length(net.Yts_hat{i}),net.Yts{i},'b:','LineWidth',2);
xlabel('Time Cycles ','FontName','Times New Roman','FontSize',14);
ylabel('RUL','FontName','Times New Roman','FontSize',14);
legend('Predicted RUL','desired RUL');
title(['Engine :' num2str(i)],'FontName','Times New Roman','FontSize',14);

%grid
subplot(1,4,2)
i=34;
plot(1:length(net.Yts_hat{i}),net.Yts_hat{i},'r*',1:length(net.Yts_hat{i}),net.Yts{i},'b:','LineWidth',2);
xlabel('Time Cycles','FontName','Times New Roman','FontSize',14);
ylabel('RUL','FontName','Times New Roman','FontSize',14);
legend('Predicted RUL','desired RUL');
title(['Engine :' num2str(i)],'FontName','Times New Roman','FontSize',14);
%grid
subplot(1,4,3)
i=35;
plot(1:length(net.Yts_hat{i}),net.Yts_hat{i},'r*',1:length(net.Yts_hat{i}),net.Yts{i},'b:','LineWidth',2);
xlabel('Time Cycles','FontName','Times New Roman','FontSize',14);
ylabel('RUL','FontName','Times New Roman','FontSize',14);
legend('Predicted RUL','desired RUL');
title(['Engine :' num2str(i)],'FontName','Times New Roman','FontSize',14);

%grid
subplot(1,4,4)
i=31;
plot(1:length(net.Yts_hat{i}),net.Yts_hat{i},'r*',1:length(net.Yts_hat{i}),net.Yts{i},'b:','LineWidth',2);
xlabel('Time Cycles' ,'FontName','Times New Roman','FontSize',14);
ylabel('RUL','FontName','Times New Roman','FontSize',14);
legend('Predicted RUL','desired RUL');
title(['Engine :' num2str(i)],'FontName','Times New Roman','FontSize',14);
%grid
clear  i

end