function varargout = TD_SOS_ELM(varargin)
% TD_SOS_ELM MATLAB code for TD_SOS_ELM.fig
%      TD_SOS_ELM, by itself, creates a new TD_SOS_ELM or raises the existing
%      singleton*.
%
%      H = TD_SOS_ELM returns the handle to a new TD_SOS_ELM or the handle to
%      the existing singleton*.
%
%      TD_SOS_ELM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TD_SOS_ELM.M with the given input arguments.
%
%      TD_SOS_ELM('Property','Value',...) creates a new TD_SOS_ELM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TD_SOS_ELM_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TD_SOS_ELM_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help TD_SOS_ELM

% Last Modified by GUIDE v2.5 26-Jan-2020 09:09:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TD_SOS_ELM_OpeningFcn, ...
                   'gui_OutputFcn',  @TD_SOS_ELM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TD_SOS_ELM is made visible.
function TD_SOS_ELM_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to TD_SOS_ELM (see VARARGIN)

% Choose default command line output for TD_SOS_ELM
%% show logos
axes(handles.axes5);%show  your logo 
imshow('logos\\GI.jpg');
axes(handles.axes6);%show  your logo 
imshow('logos\\Univ.jpg');
axes(handles.axes10);%show  your logo 
imshow('logos\\TB.jpg');
axes(handles.axes8);%show  your logo 
imshow('logos\\algerie.png');
axes(handles.axes7);%show  your logo 
imshow('logos\\LAP.jpg');
% delete('data\\Newdata.mat','data\\net.mat')
handles.output = hObject;
%% bottons sellection
set(handles.pushbutton2,'Enable','off');
set(handles.pushbutton3,'Enable','off');
set(handles.UniteN,'Enable','off');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes TD_SOS_ELM wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = TD_SOS_ELM_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function n_Callback(hObject, eventdata, handles)
% hObject    handle to n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n as text
%        str2double(get(hObject,'String')) returns contents of n as a double


% --- Executes during object creation, after setting all properties.
function n_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function G_Callback(hObject, eventdata, handles)
% hObject    handle to G (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of G as text
%        str2double(get(hObject,'String')) returns contents of G as a double


% --- Executes during object creation, after setting all properties.
function G_CreateFcn(hObject, eventdata, handles)
% hObject    handle to G (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function LambdaMin_Callback(hObject, eventdata, handles)
% hObject    handle to LambdaMin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LambdaMin as text
%        str2double(get(hObject,'String')) returns contents of LambdaMin as a double


% --- Executes during object creation, after setting all properties.
function LambdaMin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LambdaMin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function C_Callback(hObject, eventdata, handles)
% hObject    handle to C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of C as text
%        str2double(get(hObject,'String')) returns contents of C as a double


% --- Executes during object creation, after setting all properties.
function C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Mu_Callback(hObject, eventdata, handles)
% hObject    handle to Mu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Mu as text
%        str2double(get(hObject,'String')) returns contents of Mu as a double


% --- Executes during object creation, after setting all properties.
function Mu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Mu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function gamma_Callback(hObject, eventdata, handles)
% hObject    handle to gamma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of gamma as text
%        str2double(get(hObject,'String')) returns contents of gamma as a double


% --- Executes during object creation, after setting all properties.
function gamma_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gamma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Arch_Callback(hObject, eventdata, handles)
% hObject    handle to Arch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Arch as text
%        str2double(get(hObject,'String')) returns contents of Arch as a double


% --- Executes during object creation, after setting all properties.
function Arch_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Arch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function UniteN_Callback(hObject, eventdata, handles)
% hObject    handle to UniteN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of UniteN as text
%        str2double(get(hObject,'String')) returns contents of UniteN as a double


% --- Executes during object creation, after setting all properties.
function UniteN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to UniteN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Initialize
clc 
addpath('TD_ELM','data');
rand('state',3);
%% Load data
load('FD001');  % load dataset (dataset is already prepared)
mini_batch=str2double(get(handles.n,'string')); % user desired size of mini-batch
%% Divide data 
% the training set is devided into mini-batches according to user desired size of mini-batch
% Concerning the test set is already devided according to the number of engine
[xtr,ytr]=devide_blocks(xtr_temp,ytr_temp,mini_batch);
clear mini_batch ytr_temp xtr_temp

%% Training Options {Hyperparameters}
arch=str2num(get(handles.Arch,'string'));
Options.SAEs_Architecture=arch; % Architecture of the SAEs
Options.activF=get(handles.G,'string');    % Activation function
Options.Neurons=arch(end);     % Number of neurons in  supervised learning
Options.lambdaMin=str2double(get(handles.LambdaMin,'string'));  % Minimalvalue of forgetting factor
Options.mu=str2double(get(handles.Mu,'string'));        % Sensitivity factor controls the speed of convergence of the forgetting factor 
Options.gamma=str2double(get(handles.gamma,'string'));       % Discounting fctor
Options.C=str2double(get(handles.C,'string'));         % Regularization parameter (to reduce structural risk)
%% Training of SAEs (Unsupervised Learning)
[SAEs]=TD_SAEs(xtr,xts,Options);
%% show results in the interface gui
set(handles.S_trr,'string',SAEs.Tr_RMSE);
set(handles.S_tsr,'string',SAEs.Ts_RMSE);
set(handles.S_trt,'string',SAEs.Tr_Time);
set(handles.S_tst,'string',SAEs.Ts_Time);
xtr=SAEs.mapping_Train;
xts=SAEs.mapping_Test;
%% save results for futute processing
save('data\\Newdata','xtr','xts','ytr','yts','Options');
%% management of buttons and input parameters 
% bottons
set(handles.pushbutton2,'Enable','on');
set(handles.pushbutton1,'Enable','off');
% parameters
set(handles.Arch,'Enable','off');
set(handles.G,'Enable','off');    
set(handles.LambdaMin,'Enable','off');  
set(handles.Mu,'Enable','off');        
set(handles.gamma,'Enable','off');       
set(handles.C,'Enable','off');    
set(handles.n,'Enable','off');

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%
clc
addpath('TD_ELM','data');
rand('state',3);
load('Newdata')
%% Training and evaluation process (Supervised Learning)
[net]=TD_OSELM(xtr,ytr,xts,yts,Options);
%% show results in the interface gui
set(handles.trr,'string',net.tr_acc);
set(handles.tsr,'string',net.ts_acc);
set(handles.trt,'string',net.Tr_Time);
set(handles.tst,'string',net.Ts_Time);
set(handles.Score,'string',net.S_value);
save('data\\net','net');
%% avtivate buttons
set(handles.pushbutton3,'Enable','on');
set(handles.pushbutton2,'Enable','off');
set(handles.UniteN,'Enable','on');
% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load('net')
%% plot(RUL) of a set of engines from the test set
% the user has the ability to choose any engine , 
% i: is the desired  number of engine 
axes(handles.axes2);
i=str2double(get(handles.UniteN,'string'));
plot(1:length(net.Yts_hat{i}),net.Yts_hat{i},'r*',1:length(net.Yts_hat{i}),net.Yts{i},'b:');
xlabel('Time Cycles ','FontName','Times New Roman','FontSize',8);
ylabel('RUL','FontName','Times New Roman','FontSize',8);
%legend('Predicted RUL','desired RUL');
title(['Engine :' num2str(i)],'FontName','Times New Roman','FontSize',8);
%% plot Score
axes(handles.axes3);
[~,S,d,er]=Score(net.Yts_hat{i}',net.Yts{i});
i=str2double(get(handles.UniteN,'string'));
plot(d,S,'r.',d,er,'b.');
xlabel('RUL error ','FontName','Times New Roman','FontSize',8);
ylabel('Score,RMSE','FontName','Times New Roman','FontSize',8);
%legend('Predicted RUL','desired RUL');
title(['Engine :' num2str(i)],'FontName','Times New Roman','FontSize',8);


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% variables  & buttons management
% buttons
set(handles.pushbutton1,'Enable','on');
set(handles.pushbutton3,'Enable','off');
% variables
set(handles.UniteN,'Enable','off');
% parameters
set(handles.Arch,'Enable','on');
set(handles.G,'Enable','on');    
set(handles.LambdaMin,'Enable','on');  
set(handles.Mu,'Enable','on');        
set(handles.gamma,'Enable','on');       
set(handles.C,'Enable','on');    
set(handles.n,'Enable','on');
% 
axes(handles.axes2)
cla
axes(handles.axes3)
cla
%% initialize results
set(handles.trr,'string','...');
set(handles.tsr,'string','...');
set(handles.trt,'string','...');
set(handles.tst,'string','...');
set(handles.Score,'string','...');
set(handles.S_trr,'string','...');
set(handles.S_tsr,'string','...');
set(handles.S_trt,'string','...');
set(handles.S_tst,'string','...');
